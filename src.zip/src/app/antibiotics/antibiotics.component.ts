import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-antibiotics',
  templateUrl: './antibiotics.component.html',
  styleUrls: ['./antibiotics.component.css']
})
export class AntibioticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
