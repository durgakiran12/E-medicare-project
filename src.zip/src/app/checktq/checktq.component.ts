import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-checktq',
  templateUrl: './checktq.component.html',
  styleUrls: ['./checktq.component.css']
})
export class ChecktqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
