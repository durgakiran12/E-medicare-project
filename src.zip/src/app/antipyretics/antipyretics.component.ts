import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-antipyretics',
  templateUrl: './antipyretics.component.html',
  styleUrls: ['./antipyretics.component.css']
})
export class AntipyreticsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
