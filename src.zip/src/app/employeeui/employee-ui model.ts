



export class EmployeeModel{
    id:number=0;
    img:string ='';
    productName:string ='';
    brand:string ='';
    qty:string= '';

    price:string = '';

    

}